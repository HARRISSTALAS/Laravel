<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class daftar_mhs extends Model
{
    //
}
